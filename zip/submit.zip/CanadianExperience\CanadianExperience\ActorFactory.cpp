/**
 * \file ActorFactory.cpp
 *
 * \author Geoffrey Witherington-Perkins
 */

#include "stdafx.h"
#include "ActorFactory.h"


/** Constructor */
CActorFactory::CActorFactory()
{
}


/** Destructor */
CActorFactory::~CActorFactory()
{
}
